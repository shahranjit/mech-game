using UnityEngine;
using UnityEngine.UI; // For UI elements like sliders

public class HealthManager : MonoBehaviour
{
    public float maxHealth = 100f;  // Max health value
    public float currentHealth;     // Current health value
    public Slider healthSlider;     // Reference to the health bar slider

    void Start()
    {
        currentHealth = maxHealth; // Set initial health to max
        healthSlider.maxValue = maxHealth;  // Set slider's max value
        healthSlider.value = currentHealth; // Set initial slider value
    }

    // Method to apply damage and update health bar
    public void TakeDamage(float damage)
    {
        currentHealth -= damage;
        healthSlider.value = currentHealth;  // Update the health slider

        // If health reaches 0, handle the mech's destruction (optional)
        if (currentHealth <= 0)
        {
            currentHealth = 0;
            // Optionally, destroy the mech or trigger a game-over state
        }
    }
}
