using UnityEngine;
using UnityEngine.UI;
using TMPro; // For TextMeshPro (if you're using it)

public class SpeedManager : MonoBehaviour
{
    public Slider speedSlider; // Reference to the speed bar slider
    public TextMeshProUGUI speedText; // Optional: For displaying the speed as text
    private Rigidbody rb; // Reference to the mech's Rigidbody
    public float maxSpeed = 100f; // Max speed value

    void Start()
    {
        rb = GetComponent<Rigidbody>(); // Get the Rigidbody component
        speedSlider.maxValue = maxSpeed; // Set the max value for the speed slider
        speedSlider.value = 0; // Set initial speed to 0
    }

    void Update()
    {
        // Calculate the current speed using the Rigidbody's velocity
        float currentSpeed = rb.linearVelocity.magnitude;
        speedSlider.value = currentSpeed; // Update the speed bar

        // Optional: Update the speed text display
        if (speedText != null)
        {
            speedText.text = "Speed: " + currentSpeed.ToString("F0"); // Display speed value
        }
    }
}
